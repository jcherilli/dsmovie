package com.devsuperior.desmovie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesmovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesmovieApplication.class, args);
	}

}
